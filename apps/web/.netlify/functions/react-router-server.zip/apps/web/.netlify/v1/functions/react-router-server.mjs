
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// apps/web/build/server/server.js
import { createRequestHandler } from "@netlify/vite-plugin-react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { PassThrough } from "node:stream";
import { createReadableStreamFromReadable } from "@react-router/node";
import { ServerRouter, useParams, useLoaderData, useActionData, useMatches, Meta, Links, ScrollRestoration, Scripts, Outlet } from "react-router";
import { isbot } from "isbot";
import { renderToPipeableStream } from "react-dom/server";
import { createElement } from "react";
import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { z } from "zod";
import camelcaseKeys from "camelcase-keys";
import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { cuid2 } from "drizzle-cuid2/postgres";
import { count, max, eq, desc } from "drizzle-orm";
import { Table } from "react-daisyui";
var streamTimeout = 5e3;
function handleRequest(request, responseStatusCode, responseHeaders, routerContext, loadContext) {
  return new Promise((resolve, reject) => {
    let shellRendered = false;
    let userAgent = request.headers.get("user-agent");
    let readyOption = userAgent && isbot(userAgent) || routerContext.isSpaMode ? "onAllReady" : "onShellReady";
    const { pipe, abort } = renderToPipeableStream(
      /* @__PURE__ */ jsx(ServerRouter, { context: routerContext, url: request.url }),
      {
        [readyOption]() {
          shellRendered = true;
          const body = new PassThrough();
          const stream = createReadableStreamFromReadable(body);
          responseHeaders.set("Content-Type", "text/html");
          resolve(
            new Response(stream, {
              headers: responseHeaders,
              status: responseStatusCode
            })
          );
          pipe(body);
        },
        onShellError(error) {
          reject(error);
        },
        onError(error) {
          responseStatusCode = 500;
          if (shellRendered) {
            console.error(error);
          }
        }
      }
    );
    setTimeout(abort, streamTimeout + 1e3);
  });
}
var entryServer = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: handleRequest,
  streamTimeout
}, Symbol.toStringTag, { value: "Module" }));
function withComponentProps(Component) {
  return function Wrapped() {
    const props = {
      params: useParams(),
      loaderData: useLoaderData(),
      actionData: useActionData(),
      matches: useMatches()
    };
    return createElement(Component, props);
  };
}
function Layout({
  children
}) {
  return /* @__PURE__ */ jsxs("html", {
    lang: "en",
    children: [/* @__PURE__ */ jsxs("head", {
      children: [/* @__PURE__ */ jsx("meta", {
        charSet: "utf-8"
      }), /* @__PURE__ */ jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      }), /* @__PURE__ */ jsx(Meta, {}), /* @__PURE__ */ jsx(Links, {})]
    }), /* @__PURE__ */ jsxs("body", {
      children: [children, /* @__PURE__ */ jsx(ScrollRestoration, {}), /* @__PURE__ */ jsx(Scripts, {})]
    })]
  });
}
var root = withComponentProps(function App() {
  return /* @__PURE__ */ jsx(Outlet, {});
});
var route0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Layout,
  default: root
}, Symbol.toStringTag, { value: "Module" }));
var configSchema = z.object({
  APPLICATION_NAME: z.string({ description: "The name the application reports in its logs." }).default("tally"),
  NODE_ENV: z.enum(["development", "test", "production"], {
    message: "NODE_ENV must be one of: development, test, production",
    description: "The environment the application is running in."
  }).default("development"),
  NEON_URL: z.string({
    message: "NEON_URL must be provided",
    description: "The full url to the Neon PostgreSQL database."
  }).url("NEON_URL must be a valid postgresql URL")
}).transform((config22) => camelcaseKeys(config22));
var config = configSchema.parse(process.env);
process.env = { HINT: "Use the application configuration" };
var sql = neon(config.neonUrl);
var db = drizzle(sql);
var items = pgTable("items", {
  id: cuid2("id").notNull().defaultRandom().primaryKey(),
  description: text("description").notNull(),
  createdBy: cuid2("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => /* @__PURE__ */ new Date())
});
var tallies = pgTable("tallies", {
  id: cuid2("id").notNull().defaultRandom().primaryKey(),
  itemId: cuid2("item_id").notNull(),
  createdBy: cuid2("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
});
var meta = () => {
  return [{
    title: "Tally"
  }];
};
async function loader() {
  const allItems = await db.select({
    id: items.id,
    description: items.description,
    tally: count(tallies.id),
    lastTalliedAt: max(tallies.createdAt)
  }).from(items).innerJoin(tallies, eq(items.id, tallies.itemId)).groupBy(items.id).orderBy(desc(items.createdAt));
  return allItems.map((i) => ({
    id: i.id,
    description: i.description,
    tally: i.tally,
    lastTalliedAt: i.lastTalliedAt
  }));
}
var _index = withComponentProps(function Index() {
  const data = useLoaderData();
  return /* @__PURE__ */ jsxs("div", {
    className: "container mx-auto py-4",
    children: [/* @__PURE__ */ jsx("h1", {
      className: "text-4xl font-extrabold",
      children: "Hello World"
    }), /* @__PURE__ */ jsxs(Table, {
      children: [/* @__PURE__ */ jsxs(Table.Head, {
        children: [/* @__PURE__ */ jsx("span", {
          children: "Description"
        }), /* @__PURE__ */ jsx("span", {
          children: "Tally"
        }), /* @__PURE__ */ jsx("span", {
          children: "Last Updated"
        })]
      }), /* @__PURE__ */ jsx(Table.Body, {
        children: data.map((item) => {
          var _a;
          return /* @__PURE__ */ jsxs(Table.Row, {
            children: [/* @__PURE__ */ jsx("span", {
              children: item.description
            }), /* @__PURE__ */ jsx("span", {
              children: item.tally
            }), /* @__PURE__ */ jsx("span", {
              children: (_a = item.lastTalliedAt) == null ? void 0 : _a.toISOString()
            })]
          }, item.id);
        })
      })]
    })]
  });
});
var route1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: _index,
  loader,
  meta
}, Symbol.toStringTag, { value: "Module" }));
var serverManifest = { "entry": { "module": "/assets/entry.client-D1haF8y_.js", "imports": ["/assets/chunk-K6AXKMTT-BONlmvbd.js"], "css": [] }, "routes": { "root": { "id": "root", "parentId": void 0, "path": "", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/root-Cd8aQrhV.js", "imports": ["/assets/chunk-K6AXKMTT-BONlmvbd.js", "/assets/with-props-Cyb_8T1g.js"], "css": ["/assets/root-D7iQQCzs.css"] }, "routes/_index": { "id": "routes/_index", "parentId": "root", "path": void 0, "index": true, "caseSensitive": void 0, "hasAction": false, "hasLoader": true, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/_index-Dvc7qyBY.js", "imports": ["/assets/with-props-Cyb_8T1g.js", "/assets/chunk-K6AXKMTT-BONlmvbd.js"], "css": [] } }, "url": "/assets/manifest-22c6cc6a.js", "version": "22c6cc6a" };
var assetsBuildDirectory = "build/client";
var basename = "/";
var future = { "unstable_optimizeDeps": false };
var isSpaMode = false;
var publicPath = "/";
var entry = { module: entryServer };
var routes = {
  "root": {
    id: "root",
    parentId: void 0,
    path: "",
    index: void 0,
    caseSensitive: void 0,
    module: route0
  },
  "routes/_index": {
    id: "routes/_index",
    parentId: "root",
    path: void 0,
    index: true,
    caseSensitive: void 0,
    module: route1
  }
};
var build = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  assets: serverManifest,
  assetsBuildDirectory,
  basename,
  entry,
  future,
  isSpaMode,
  publicPath,
  routes
}, Symbol.toStringTag, { value: "Module" }));
var _virtual_netlifyServer = createRequestHandler({
  build,
  getLoadContext: async (_req, ctx) => ctx
});

// apps/web/.netlify/v1/functions/react-router-server.mjs
var config2 = {
  name: "React Router server handler",
  generator: "@netlify/vite-plugin-react-router@1.0.0",
  path: "/*",
  preferStatic: true
};
export {
  config2 as config,
  _virtual_netlifyServer as default
};
